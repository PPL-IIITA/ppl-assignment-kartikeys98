class Cheats:
	def __init__(self, rollno, gender, intelligenceLevel, marks, Cvar, caught, reputationFactor):
		self.rollno = rollno
		self.gender = gender
		self.intelligenceLevel = intelligenceLevel
		self.marks = marks
		self.Cvar = Cvar
		self.caught = caught
		self.reputationFactor = reputationFactor

	def calculate(self):
		if caught > 0.8:
			return  -self.reputationFactor
		else:
			return min((10*self.intelligenceLevel + Cvar), 10)


