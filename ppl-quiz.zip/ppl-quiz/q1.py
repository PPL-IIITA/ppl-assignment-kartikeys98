from luck import Luck
from cursed import Cursed
from cheats import Cheats
import csv
from random import randint

l =	[]
cu = []
ch = []


n = input()

def generate():
	with open('input_1.csv', 'w') as csvfile:
		fieldnames = ['Rollno', 'Gender', 'Intelligence', 'Marks', 'Type', 'Luck', 'C', 'caught', 'ReputationFactor']
		writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
		writer.writeheader()
		# i = 1
		# while i <= n:
		# 	spam = {'Rollno': str(i), 'Gender': 'm', 'Intelligence': randint(0,1), 'Marks':
		# 	writer.writerow(spam)
generate()
print('Now enter in the text file input_1.csv')

txtFile = open('rit2015006_1.txt', 'w')
readingFile = open('input_1.csv', 'r')
with open('input_1.csv') as csvfile:
	reader = csv.DictReader(csvfile)
	for row in reader:
		rollno = row['Rollno']
		gender = row['Gender']
		intelligence = row['Intelligence']
		marks = row['Marks']
		type = row['Type']
		if type == 0:
			luck = row['Luck']
			l.append(Luck(rollno, gender, intelligence, marks, luck))
		elif type == 1:
			cu.append(Cursed(rollno, gender, intelligence, marks))
		elif type == 3:
			c = row['C']
			caught = row['caught']
			repfactor = row['ReputationFactor']
			ch.append(Cheats(rollno, gender, intelligence, marks, c, caught, repfactor))

for i in l:
	txtFile.write(i.rollno + i.calculate() + i.gender  + i.intelligenceLevel + i.luckFactor)
for j in cu:
	txtFile.write(j.rollno + j.calculate() + j.gender  + j.intelligenceLevel )
for k in ch:
	txtFile.write(k.rollno + k.calculate() + k.gender  + k.intelligenceLevel + k.Cvar + k.caught + k.reputationFactor)
txtFile.close()

