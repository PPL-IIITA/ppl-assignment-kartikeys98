class Luck:
	def __init__(self, rollno, gender, intelligenceLevel, marks, luckFactor):
		self.rollno = rollno
		self.gender = gender
		self.intelligenceLevel = intelligenceLevel
		self.marks = marks
		self.luckFactor = luckFactor
	def calculate(self):
		return 10 * self.intelligenceLevel * self.luckFactor