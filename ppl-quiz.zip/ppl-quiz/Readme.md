1) Run program using python3 q1.py
2) Please enter into the text file input_1.csv after running the program when it says so.
3) for documentation in documentation/index.html
