class Cursed:
	def __init__(self, rollno, gender, intelligenceLevel, marks):
		self.rollno = rollno
		self.gender = gender
		self.intelligenceLevel = intelligenceLevel
		self.marks = marks

	def calculate(self):
		return max((10*self.intelligenceLevel-1), 0)

